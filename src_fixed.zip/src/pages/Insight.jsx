import React from "react";
export default function XYZ() {
  return (
    <div className="min-h-screen flex items-center justify-center text-gray-500">
      XYZ page coming soon…
    </div>
  );
}